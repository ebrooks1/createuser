<?php
	function createUSer($fname, $username, $password, $email, $userlvl) {
		include('connect.php');
		$userString = "INSERT INTO tbl_user VALUES(NULL, '{$fname}', '{$username}', '{$password}', '{$email}', NULL, '{$userlvl}', 'no', 0)";
	//echo $userString;
		$userQuery = mysqli_query($link, $userString);
			if($userQuery) {
				sendmessage($email, $username, $password);
				//send email message here. Files from last here. email needs username/password and url admin_login.php. SEPERATE mail.php file. put it in the config file and call to it.
				redirect_to("admin_index.php");
			}else{
				$message = "There was a problem setting up this user. Maybe reconsidder your hiring practices.";
				return $message;
			}

		mysqli_close($link);
	}

function editUser($id, $fname, $username, $password, $email) {
	include('connect.php');
	$updatestring = "UPDATE tbl_user SET user_fname='{$fname}', user_name='{$username}', user_pass='{$password}', useR_email='{$email}', user_flag=1 WHERE user_id=$id";
	//echo $updatestring;
	$updatequery = mysqli_query($link, $updatestring);
	if  ($updatequery) {
		redirect_to("admin_index.php");
	}else{
		$message = "There was a problem changing your information, please contact your web admin.";
		return $message;
	}

	mysqli_close($link);
} 

//function for creating generated passwords
function deleteUser($id) {
	//echo $id;
	include('connect.php');
	$delstring = "DELETE FROM tbl_user WHERE user_id={$id}";
	$delquery = mysqli_query($link, $delstring);
	if($delquery){
		redirect_to("../admin_index.php");
	}else{
		$message = "F&*k, call security...";
		return $message;
	}

	mysqli_close($link);
}


?>