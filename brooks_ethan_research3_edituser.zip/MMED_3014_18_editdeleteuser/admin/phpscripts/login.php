<?php
	
	function logIn($username, $password, $ip) {
		require_once('connect.php');
			$username = mysqli_real_escape_string($link, $username);
			$password = mysqli_real_escape_string($link, $password);
			$loginstring = "SELECT * FROM tbl_user WHERE user_name = '{$username}' AND user_pass = '{$password}'";
				$user_set = mysqli_query($link, $loginstring);
				if(mysqli_num_rows($user_set)){
					$found_user = mysqli_fetch_array($user_set, MYSQLI_ASSOC);
					$id = $found_user['user_id'];
					$flag = $found_user['user_flag'];
					$_SESSION['user_id'] = $id;
					$_SESSION['user_name'] = $found_user['user_fname'];
					if(mysqli_query($link, $loginstring)){
						$updatestring = "UPDATE tbl_user SET user_ip = '$ip' WHERE user_id={$id}";
						$updatequery = mysqli_query($link, $updatestring);
					}
					if($flag==1){
					redirect_to("admin_index.php");
					}else{
					//Lock out based on time
						
					redirect_to("admin_edituser.php");
					}

				}else{
					$message = "Username and or password is incorrect.<br>Please make sure your caps lock key is turned off.";
					return $message;
				}
			
		mysqli_close($link);
	}


	//I would need some sort of if statement to find out if the person is logging in for the first time, and if they are go to the edituser page (skipping admin page), else; go to the admin page as normal.

	//Maybe I could use the database so it isn't per-session related. 

	//When user is created add a flag to the column(ie 0 or 1).


?>
